package com.mvc.dao;

import com.mvc.dto.RegisterDTO;

public interface RegisterDao {
	
	public int registerUser(RegisterDTO registerDTO);

}
