package com.mvc.service;

import com.mvc.dto.RegisterDTO;

public interface RegisterService {
	
	public int registerUser(RegisterDTO registerDTO);

}
