package com.mvc.service;

import com.mvc.dto.LoginDTO;

public interface LoginService {
	
	public String loginUser(LoginDTO loginDTO);

}
